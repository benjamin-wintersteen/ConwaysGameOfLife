This is the README for Project 2! 
When replicating the results from my project it is best to run the java Exploration file. 

When replicating the results from my first extension it is best to call  
“java LifeSimulation x x y Gliders”. This will run the Gliders version of my landscape. 
All the code for this extension is in the Landscape Class.

When replicating the results of my second extension it is best to call "java LifeSimulation x x y" 
The first two x fields will manipulate row and column lengths while y will manipulate initial percent Alive. 

When replicating the results of my third extension it is best to run "java ExplorationExtension". 